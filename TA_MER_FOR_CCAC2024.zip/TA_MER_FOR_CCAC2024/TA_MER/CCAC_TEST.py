import math
import numpy as np
import torch.utils.data as data
from torchvision import transforms
from sklearn.metrics import confusion_matrix
import pandas as pd
import os, torch
import argparse
torch.set_printoptions(precision=3, edgeitems=14, linewidth=350)
import sys
sys.path.append('./model')
from model.transformer_block import Transformer_rois
import random
from get_ccac_feature import get_test_B_feature
# 设置一个固定的随机种子
random.seed(42)


def parse_args():
    parser = argparse.ArgumentParser()

    # 数据库地址
    parser.add_argument('--ccac_test_data_path', type=str, default="I:/CCAC/test_data_B/test_data_B",
                        help='ccac data path.')
    parser.add_argument('--ccaclabel_testdata_path', type=str, default="./ME_label/CCAC2024_test_B.csv", 
                        help='CCAC label path.')
    parser.add_argument('--all_flow_save_path', type=str, default="flow_data1/ccac_test_B/",
                        help='CCAC flow save path.')
    parser.add_argument('--flowisexist', type=bool, default=False, help="")


    # 测试
    parser.add_argument('--save_model_params_test', default="./save_params/model_au_1epoch16UF10.3795931310071726.pt",
                        type=str,
                        help=" ")
    # 模型结构
    parser.add_argument('--net_name', default="transformer_rois", type=str,
                        help="a patch consist of 7*7 pixels")  # "res","l2g","alex","res_8pics_flow","transformer_rois"
    parser.add_argument('--num_classes', default=7, type=int,
                        help="Number of query slots")

    # 模型训练
    parser.add_argument('--device', type=str, default="cuda:0", help='CUDA:0')
    parser.add_argument('--batch_size', type=int, default=32, help='Batch size.')
    parser.add_argument('--optimizer', type=str, default="adam", help='Optimizer, adam or sgd.')
    parser.add_argument('--lr', type=float, default=0.005, help='Initial learning rate for sgd.')
    parser.add_argument('--momentum', default=0.9, type=float, help='Momentum for sgd')
    parser.add_argument('--workers', default=2, type=int, help='Number of data loading workers (default: 4)')
    parser.add_argument('--epochs', type=int, default=60, help='Total training epochs.')
    parser.add_argument('--drop_rate', type=float, default=0, help='Drop out rate.')

    return parser.parse_args()
class MEDataSet_cacc_test(data.Dataset):
    def __init__(self, args, transform=None, basic_aug=False, transform_norm=None,
                 data_flow_transform=None, flow_norm=None):

        ccaclabel_table = pd.read_csv(args.ccaclabel_testdata_path, header=None)
        flow_savepath = args.all_flow_save_path
        self.file_paths_on = []
        self.file_paths_flow = []
        self.file_paths_flow_rois = []

        self.label_all = []
        self.label_au = []
        self.sub = []
        self.file_names = []
        self.video_names = []

        # 计算ccac的
        for index, row in ccaclabel_table.iterrows():
            if (index >= 1):

                datapath=args.ccac_test_data_path+"/"+row[1]
                file_names = os.listdir(datapath)
                start_pic_path = file_names[0]
                start = int(start_pic_path[0:5])
                onset_path = args.ccac_test_data_path + "/" + str(row[1]) + "/" + str(
                    start).zfill(5) + ".png"
                flow_path_rois = flow_savepath + str(row[0]) + "/" + str(row[1]) + "/" + "flow_rois.npy"
                video_name = "ccac_test_B/" + str(row[0]) + "/" + str(row[1])

                self.file_paths_on.append(onset_path)
                self.file_paths_flow_rois.append(flow_path_rois)
                self.sub.append(row[0])
                self.video_names.append(video_name)
    def __len__(self):
        return len(self.file_paths_on)

    def __getitem__(self, idx):

        sub_name = self.sub[idx]
        video_name = self.video_names[idx]
        flow_path = self.file_paths_flow_rois[idx]
        try:
            flow_face = np.load(flow_path)
        except:
            print("没有成功读取"+video_name+"视频的特征")
        flow_face = torch.from_numpy(flow_face)
        roisnum, n, l = flow_face.shape
        if (n < 50):
            buling = torch.zeros((roisnum, 50 - n, l))
            flow_face = torch.cat([flow_face,buling],dim=1)
        else:
            flow_face = flow_face[:, 0:50, :]
        return flow_face, sub_name, video_name
def ccac_test():
    ##test
    test_dataset = MEDataSet_cacc_test(args)
    test_loader = torch.utils.data.DataLoader(test_dataset,
                                              batch_size=args.batch_size,
                                              num_workers=args.workers,
                                              shuffle=False,
                                              pin_memory=True)
    with torch.no_grad():
        test_pred = []
        net_flow = Transformer_rois()
        print("模型名称是Transformer_rois")
        # print(net_flow)
        net_flow.load_state_dict(torch.load(args.save_model_params_test))
        net_flow = net_flow.to(args.device)
        for batch_i, (
                flow_faces, sub_sets, video_name) in enumerate(test_loader):
            flow_faces = flow_faces.to(args.device)
            flow_faces = flow_faces.float()
            ALL = net_flow(flow_faces)
            _, cls_predicts = torch.max(ALL[:, 0:args.num_classes], 1)
            test_pred.extend(cls_predicts.tolist())
        print("预测结果是：")
        print(len(test_pred))
        print(test_pred)
        with open("pred_results/prediction.txt", "w") as file:
            for i in test_pred:
                file.writelines(str(i) + "\n")

if __name__ == "__main__":
    args = parse_args()
    #不存在特征的时候，计算特征并存储到args.all_flow_save_path中
    if args.flowisexist is False:
        get_test_B_feature(args.ccac_test_data_path,args.ccaclabel_testdata_path,args.all_flow_save_path)
    #计算特征后直接进行分析分类
    ccac_test()


