import math
import numpy as np

import torch.utils.data as data
from torchvision import transforms

from sklearn.metrics import confusion_matrix
import pandas as pd
import  torch

from sklearn.model_selection import KFold
import argparse
from tensorboardX import SummaryWriter
torch.set_printoptions(precision=3, edgeitems=14, linewidth=350)
import sys
import os
sys.path.append('./model')

from model.transformer_block import Transformer_rois


import random
from get_ccac_feature import get_train_feature




def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed) # CPU
    torch.cuda.manual_seed(seed) # GPU
    torch.cuda.manual_seed_all(seed) # All GPU
    os.environ['PYTHONHASHSEED'] = str(seed) # 禁止hash随机化
    torch.backends.cudnn.deterministic = True # 确保每次返回的卷积算法是确定的
    torch.backends.cudnn.benchmark = False # True的话会自动寻找最适合当前配置的高效算法，来达到优化运行效率的问题。False保证实验结果可复现



def parse_args():
    parser = argparse.ArgumentParser()

    # 数据库地址

    parser.add_argument('--ccac_data_path', type=str,
                        default="J:/dataset_ME/new_dataset/train_data/train_data",
                        help='ccac data path.')
    # A榜数据库 "J:/dataset_ME/new_dataset/test_data_A/test_data_A",  B榜数据库"I:/CCAC/test_data_B/test_data_B"

    parser.add_argument('--ccaclabel_path', type=str, default="ME_label/CCAC2024.csv",
                        help='CCAC label path.')
    parser.add_argument('--all_flow_save_path', type=str, default="flow_data/ccac_train_val/",
                        help='CCAC flow save path.')
     #A榜标签 "./ME_label/CCAC2024_test_A_withstart.csv",  B榜标签"./ME_label/CCAC2024_test_B.csv"

    parser.add_argument('--flowisexist', type=bool, default=True, help="")
    # 是否使用数据库

    parser.add_argument('--use_ccac', type=bool, default=True, help='use the ccac dataset.')

    parser.add_argument('--calculateflow', type=bool, default=True, help='')

    # 输入是啥
    parser.add_argument('--use_flow', default=True, type=bool,
                        help="use flow")
    parser.add_argument('--use_rois', default=True, type=bool,
                        help="the numbers of pictures as input")
    # 训练or测试

    # 训练目标
    parser.add_argument('--MECLASS_DECTION', default=True, type=bool,
                        help="recog the ME class")
    parser.add_argument('--use_7cate', default=True, type=bool,
                        help="recog 7 cate")
    parser.add_argument('--use_3cate', default=False, type=bool,
                        help="recog 3 cate")
    parser.add_argument('--num_classes', default=7, type=int,
                        help="Number of query slots")


    # 训练集和测试集的分割方式
    parser.add_argument('--use_5_k', default=True, type=bool,
                        help="recog the ME class")
    # 模型结构
    parser.add_argument('--net_name', default="transformer_rois", type=str,
                        help="a patch consist of 7*7 pixels")  # "res","l2g","alex","res_8pics_flow","transformer_rois"

    # 模型训练
    parser.add_argument('--device', type=str, default="cuda:0", help='CUDA:0')
    parser.add_argument('--batch_size', type=int, default=32, help='Batch size.')
    parser.add_argument('--optimizer', type=str, default="adam", help='Optimizer, adam or sgd.')
    parser.add_argument('--lr', type=float, default=0.005, help='Initial learning rate for sgd.')
    parser.add_argument('--momentum', default=0.9, type=float, help='Momentum for sgd')
    parser.add_argument('--workers', default=2, type=int, help='Number of data loading workers (default: 4)')
    parser.add_argument('--epochs', type=int, default=25, help='Total training epochs.')
    parser.add_argument('--drop_rate', type=float, default=0, help='Drop out rate.')

    return parser.parse_args()




class MEDataSet(data.Dataset):
    def __init__(self, args, phase, train_loso, test_loso, transform=None, basic_aug=False, transform_norm=None,
                 data_flow_transform=None, flow_norm=None):

        ccaclabel_table_all = pd.read_csv(args.ccaclabel_path, header=None)
        flow_savepath = "flow_data/"
        # print(args.delete_smic)
        if phase == 'train':
            ccaclabel_table = ccaclabel_table_all
            for ss in test_loso:
                if (len(ss) == 7 and "sub" in ss):
                    ccaclabel_table = ccaclabel_table.loc[ccaclabel_table[0] != ss]
            # print("训练数量")
            # print(ccaclabel_table.shape)

        else:
            ccaclabel_table = ccaclabel_table_all
            for ss in train_loso:
                if (len(ss) == 7 and "sub" in ss):  # subject属于mdME
                    ccaclabel_table = ccaclabel_table.loc[ccaclabel_table[0] != ss]
            # print("测试数量")
            # print(ccaclabel_table.shape)

        self.file_paths_on=[]
        self.file_paths_flow_8pics = []
        self.file_paths_flow_rois = []

        self.file_paths_pic1 = []
        self.file_paths_pic2 = []
        self.file_paths_pic3 = []
        self.file_paths_pic4 = []
        self.file_paths_pic5 = []
        self.file_paths_pic6 = []
        self.file_paths_pic7 = []
        self.file_paths_pic8 = []

        self.label_all = []
        self.label_7cates = []
        self.sub = []
        self.file_names = []
        self.video_names = []
        if (args.use_ccac == True):

            # 计算ccac的
            for index, row in ccaclabel_table.iterrows():
                # print(index)
                if (index > 1):
                    emo = row[5]
                    emotion_for7cate = row[6]
                    if emo in "others":
                        continue
                    elif emo in "happiness":
                        emotion = 1
                    elif emo in "surprise":
                        emotion = 2
                    else:
                        emotion = 0

                    onset_path=args.ccac_data_path + "/" + str(row[1]) + "/" + str(
                        row[2]).zfill(5) + ".png"

                    flow_path_rois = flow_savepath + "ccac_train_val/" + str(row[0]) + "/" + str(row[1]) + "/" + "flow_rois.npy"

                    self.file_paths_flow_rois.append(flow_path_rois)
                    self.sub.append(row[0])
                    self.file_paths_on.append(onset_path)



                    if (args.use_7cate == True):
                        self.label_7cates.append(int(emotion_for7cate))
                    elif (args.use_3cate == True):
                        self.label_all.append(emotion)
                    video_name = "ccac/" + str(row[0]) + "/" + str(row[1])
                    # au_list = get_clean(au_list)
                    self.video_names.append(video_name)
        # print(self.file_paths_apex)
        self.phase = phase
        self.basic_aug = basic_aug
        self.transform = transform
        self.transform_norm = transform_norm
        self.flow_transform = data_flow_transform
        self.flow_norm = flow_norm
        # self.aug_func = [image_utils.flip_image,image_utils.add_gaussian_noise]

        self.use_rois=args.use_rois
        self.use_flow=args.use_flow

    def __len__(self):
        return len(self.file_paths_flow_rois)

    def __getitem__(self, idx):
        ##sampling strategy for training set
        flow_face = torch.zeros((2, 3))
        if (self.use_flow == True):
           if(self.use_rois == True):  #因为对于训练和测试是一致的
                flow_path=self.file_paths_flow_rois[idx]
                flow_face = np.load(flow_path)
                flow_face = torch.from_numpy(flow_face)
                roisnum,n,l=flow_face.shape
                if(n<50):
                    buling=torch.zeros((roisnum,50-n,l))
                    flow_face=torch.cat([flow_face,buling],dim=1)
                else:
                    flow_face = flow_face[:,0:50,:]
           if (self.flow_transform is not None) and (self.use_rois == False):
                if (type(flow_face) == torch.Tensor):
                    flow_face = flow_face.numpy()
                flow_face = self.flow_transform(flow_face)
                if self.flow_norm is not None and self.phase == 'train':
                    flow_face = self.flow_norm(flow_face)

        label_all = self.label_7cates[idx]
        sub_name = self.sub[idx]
        video_name = self.video_names[idx]
        return  label_all, flow_face, sub_name, video_name

def confusionMatrix(gt, pred, show=False):
    # print(gt)
    # print(pred)
    TN, FP, FN, TP = confusion_matrix(gt, pred).ravel()
    f1_score = (2 * TP + 0.000001) / (2 * TP + FP + FN + 0.000001)
    num_samples = len([x for x in gt if x == 1])
    average_recall = TP / num_samples
    return f1_score, average_recall

def recognition_evaluation(final_gt, final_pred):
    label_dict = {'negative': 0, 'positive': 1, 'surprise': 2}
    label_dict = {'anger': 0, 'contempt': 1, 'disgust': 2, 'fear': 3, 'happiness': 4, 'sadness': 5, 'surprise': 6}
    # Display recognition result
    f1_list = []
    ar_list = []
    try:
        for emotion, emotion_index in label_dict.items():
            gt_recog = [1 if x == emotion_index else 0 for x in final_gt]
            pred_recog = [1 if x == emotion_index else 0 for x in final_pred]
            try:
                f1_recog, ar_recog = confusionMatrix(gt_recog, pred_recog)
                f1_list.append(f1_recog)
                ar_list.append(ar_recog)
            except Exception as e:
                pass
        UF1 = np.mean(f1_list)
        UAR = np.mean(ar_list)
        return UF1, UAR
    except:
        return '', ''

def run_training_flow(args):
    data_transforms = transforms.Compose([
        # transforms.ToPILImage(),
        # transforms.Resize((224, 224)),

        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225]),

    ])
    data_flow_transforms = transforms.Compose([
        # transforms.ToPILImage(),
        # transforms.Resize((224, 224)),

        transforms.ToTensor(),
        # transforms.Normalize(mean=[0.057, 0.025],
        #                      std=[0.516, 0.494]),

    ])
    ### data augmentation for training set only
    data_transforms_norm = transforms.Compose([

        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomRotation(4),
        transforms.RandomCrop(224, padding=4),

    ])
    flow_transforms_norm = transforms.Compose([

        # transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomRotation(4),
        transforms.RandomCrop(224, padding=4),

    ])

    ### data normalization for both teating set
    data_transforms_val = transforms.Compose([
        # transforms.ToPILImage(),
        # transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])])
    # leave one subject out protocal
    ccac_subs = ['sub0590', 'sub0184', 'sub0027', 'sub0047', 'sub0171', 'sub0009', 'sub0022', 'sub0196', 'sub0598',
                 'sub0186', 'sub0193', 'sub0641', 'sub0132',
                 'sub0163', 'sub0153', 'sub0076', 'sub0650', 'sub0033', 'sub0577', 'sub0120', 'sub0057', 'sub0113',
                 'sub0140', 'sub0104', 'sub0157', 'sub0164',
                 'sub0069', 'sub0649', 'sub0099', 'sub0152', 'sub0015', 'sub0090', 'sub0135', 'sub0668', 'sub0148',
                 'sub0065', 'sub0032', 'sub0117', 'sub0004',
                 'sub0053', 'sub0133', 'sub0182', 'sub0014', 'sub0118', 'sub0059', 'sub0154', 'sub0572', 'sub0037',
                 'sub0035', 'sub0045', 'sub0645', 'sub0048',
                 'sub0664', 'sub0141', 'sub0042', 'sub0121', 'sub0143', 'sub0072', 'sub0185', 'sub0028', 'sub0063',
                 'sub0172', 'sub0187', 'sub0100', 'sub0573',
                 'sub0005', 'sub0183', 'sub0124', 'sub0013', 'sub0657', 'sub0669', 'sub0095', 'sub0012', 'sub0670',
                 'sub0160', 'sub0071', 'sub0179', 'sub0040',
                 'sub0112', 'sub0091', 'sub0073', 'sub0109', 'sub0043', 'sub0168', 'sub0010', 'sub0180', 'sub0038',
                 'sub0054', 'sub0575', 'sub0584', 'sub0646',
                 'sub0119', 'sub0116', 'sub0102', 'sub0101', 'sub0108', 'sub0079', 'sub0144', 'sub0162', 'sub0049',
                 'sub0574', 'sub0654', 'sub0089', 'sub0074',
                 'sub0003', 'sub0062', 'sub0665', 'sub0051', 'sub0653', 'sub0594', 'sub0078', 'sub0188', 'sub0017',
                 'sub0138', 'sub0019', 'sub0058', 'sub0106',
                 'sub0085', 'sub0094', 'sub0111', 'sub0123', 'sub0177', 'sub0198', 'sub0025', 'sub0599', 'sub0137',
                 'sub0647', 'sub0197', 'sub0021', 'sub0080',
                 'sub0082', 'sub0026', 'sub0087', 'sub0147', 'sub0666', 'sub0181', 'sub0165', 'sub0129', 'sub0060',
                 'sub0167', 'sub0146', 'sub0169', 'sub0667',
                 'sub0122', 'sub0084', 'sub0662', 'sub0036', 'sub0126', 'sub0039', 'sub0044', 'sub0075', 'sub0580',
                 'sub0158', 'sub0161', 'sub0194', 'sub0655',
                 'sub0661', 'sub0134', 'sub0023', 'sub0031', 'sub0150', 'sub0642', 'sub0597', 'sub0011', 'sub0105',
                 'sub0115', 'sub0200', 'sub0041', 'sub0176',
                 'sub0114', 'sub0643', 'sub0034', 'sub0093', 'sub0007', 'sub0107', 'sub0660']

    datasets = []
    LOSO = []
    sub_fortrain=[]

    if (args.use_ccac == True):
        LOSO.extend(ccac_subs)
        datasets.append("ccac")
    print("使用", datasets, "数据集")
    if (args.use_5_k == True):
        kf = KFold(n_splits=5, shuffle=True)
        train_list = []
        test_list = []
        for train_indexs, test_indexs in kf.split(LOSO):
            train_list.append(train_indexs)
            test_list.append(test_indexs)

    test_time = 0
    for train_indexs, test_indexs in zip(train_list, test_list):  # 调用split方法切分数据
        test_time += 1
        if(test_time>1):
            break
        if (args.use_5_k == True):

            # 构建数据
            test_data = []
            for test_ind in test_indexs:
                test_data.append(LOSO[test_ind])
            train_data = []
            for train_ind in train_indexs:
                train_data.append(LOSO[train_ind])
        train_data.extend(sub_fortrain)
        # for subj in LOSO:
        train_dataset = MEDataSet(args, phase='train', train_loso=train_data, test_loso=test_data,
                                  transform=data_transforms,
                                  basic_aug=True, transform_norm=data_transforms_norm,
                                  data_flow_transform=data_flow_transforms, flow_norm=flow_transforms_norm)

        val_dataset = MEDataSet(args, phase='test', train_loso=train_data, test_loso=test_data,
                                transform=data_transforms_val, data_flow_transform=data_flow_transforms)

        train_loader = torch.utils.data.DataLoader(train_dataset,
                                                   batch_size=args.batch_size,
                                                   num_workers=args.workers,
                                                   shuffle=True,
                                                   pin_memory=True)
        val_loader = torch.utils.data.DataLoader(val_dataset,
                                                 batch_size=args.batch_size,
                                                 num_workers=args.workers,
                                                 shuffle=False,
                                                 pin_memory=True)
        print('Train set', train_data)
        print('Test set', test_data)
        print('Train set size:', train_dataset.__len__())
        print('Validation set size:', val_dataset.__len__())
        criterion_cls = torch.nn.CrossEntropyLoss(weight=(torch.FloatTensor([3, 5, 1, 2, 2, 2, 2]).to(args.device)))
        ##model initialization
        if (args.net_name == "transformer_rois"):
            net_flow = Transformer_rois()
            print("Transformer_rois")
        params_all = net_flow.parameters()
        criterion = torch.nn.CrossEntropyLoss(weight=(torch.FloatTensor([3, 5, 1, 2, 2, 2, 2]).to(args.device)))
        if args.optimizer == 'adam':
            optimizer_all = torch.optim.AdamW(params_all, lr=0.0008, weight_decay=0.7)

        else:
            raise ValueError("Optimizer not supported.")
        ##lr_decay
        scheduler_all = torch.optim.lr_scheduler.ExponentialLR(optimizer_all, gamma=0.987)
        net_flow = net_flow.to(args.device)


        # 模型训练和测试
        video_list_one_epoch = []
        with SummaryWriter(log_dir='./logs', comment='train') as writer:  # 可以直接使用python的with语法，自动调用close方法
            # 数据分布直方图

            for i in range(1, args.epochs):
                running_loss = 0.0
                correct_sum = 0
                iter_cnt = 0
                net_flow.train()

                y_train_one_epoch = []
                y_train_pred_one_epoch = []
                for batch_i, (label_all, flow_faces, sub_sets,  video_name) in enumerate(train_loader):

                    iter_cnt += 1
                    # print(iter_cnt)
                    label_all = label_all.to(args.device)
                    ##train
                    if (args.use_flow):
                        flow_faces = flow_faces.to(args.device)
                        flow_faces = flow_faces.float()
                        ALL = net_flow(flow_faces)
                    loss_cls = 0
                    if (args.MECLASS_DECTION == True):
                        loss_cls = criterion_cls(ALL[:, 0:args.num_classes], label_all)
                    loss_all =  loss_cls

                    optimizer_all.zero_grad()
                    loss_all.backward()
                    optimizer_all.step()
                    running_loss += loss_all


                    if (args.MECLASS_DECTION == True):
                        _, cls_predicts = torch.max(ALL[:, 0:args.num_classes], 1)
                        y_train_one_epoch.extend(label_all.tolist())
                        y_train_pred_one_epoch.extend(cls_predicts.tolist())

                    # print("计算完一个batch", iter_cnt)
                ## lr decay
                if i <= 50:
                    scheduler_all.step()
                running_loss = running_loss / iter_cnt

                if (args.MECLASS_DECTION == True):
                    UF1_sub_one_epoch, UAR_sub_one_epoch = recognition_evaluation(y_train_one_epoch,
                                                                                  y_train_pred_one_epoch)
                    print('[Epoch %d] Training CLS_UAR: %.4f. Loss: %.3f' % (i, UAR_sub_one_epoch, running_loss))
                    # 绘制x,y随epoch变化图像
                    writer.add_scalar('data/train_UAR', UAR_sub_one_epoch, i)
                writer.add_scalar('data/train_running_loss', running_loss, i)

                ##val
                net_flow.eval()
                with torch.no_grad():
                    y_test_one_epoch = []
                    y_test_pred_one_epoch = []
                    sub_one_epoch = []

                    running_loss = 0.0
                    iter_cnt = 0
                    for batch_i, (label_all, flow_faces, sub_sets,  video_name) in enumerate(val_loader):
                        label_all = label_all.to(args.device)
                        if (args.use_flow):
                            flow_faces = flow_faces.to(args.device)
                            flow_faces = flow_faces.float()
                            ALL = net_flow(flow_faces)

                        # result
                        loss_cls = 0
                        if (args.MECLASS_DECTION == True):
                            loss_cls = criterion_cls(ALL[:, 0:args.num_classes], label_all)
                            _, cls_predicts = torch.max(ALL[:, 0:args.num_classes], 1)
                            y_test_one_epoch.extend(label_all.tolist())
                            y_test_pred_one_epoch.extend(cls_predicts.tolist())

                        loss_all = loss_cls
                        running_loss += loss_all
                        iter_cnt += 1

                        sub_one_epoch.extend(sub_sets)
                        video_list_one_epoch.extend(video_name)
                    running_loss = running_loss / iter_cnt

                    if (args.MECLASS_DECTION == True):
                        UF1_sub_one_epoch, UAR_sub_one_epoch = recognition_evaluation(y_test_one_epoch,
                                                                                      y_test_pred_one_epoch)
                        print("[Epoch %d] val Loss:%.3f, UF1-score:%.3f, UAR:%.3f" % (
                            i, running_loss, UF1_sub_one_epoch, UAR_sub_one_epoch))
                if os.path.exists("./save_params") is False:
                    os.makedirs("./save_params")
                torch.save(net_flow.state_dict(), 'save_params/model_au_' + str(test_time) + 'epoch' + str(i)+'UF1'+str(UF1_sub_one_epoch) + '.pt')

if __name__ == "__main__":
    RANDOM_SEED = 39  # any random number
    set_seed(RANDOM_SEED)
    args = parse_args()
    if args.flowisexist is False:
        get_train_feature(args.ccac_data_path,args.ccaclabel_path,args.all_flow_save_path)
    run_training_flow(args)


