

with open("pred_results/prediction.txt", 'r') as file:
    content1 = file.readlines()
with open("I:/比赛/7月1/prediction.txt", 'r') as file:
    content2 = file.readlines()
for i in range(299):
    if(content2[i] not in content1[i]):
        print(i)
